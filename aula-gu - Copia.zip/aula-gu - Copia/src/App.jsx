import { useEffect, useMemo, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {

  const [nomes, setNomes] = useState([
    'ANA GIANCOLI',
    'GUSTAVO',
    'PAULO',
    'MATHEUS'
  ]);
  const [input, setInput] = useState("");
  const [agendaStore, setAgendaStore] = useState([]);

  /*useEffect(
    () => {
      const nomesStorage = localStorage.getItem('agenda');
      if (nomesStorage) {
        setAgendaStore(JSON.parse(nomesStorage));
      }
    }, [agendaStore]
  );
*/
  useEffect(
    () => {
      localStorage.setItem('agenda', JSON.stringify(nomes));
    }, [nomes]
  );
  const total= useMemo(()=> nomes.length, [nomes])

  function adicionar() {
    setNomes([...nomes, input]);
    setInput("");
  }

  return (
    <>
      <div>
        <ul>
          {nomes.map((nome) => (
            <li key={nome}>{nome}</li>
          ))}
        </ul>
      </div>
      <div>
        Local Storage:  
        <h4>Total de nomes {total}</h4>
        <ul>
          {agendaStore.map(
            (nomeS) => (<li key={nomeS}>{nomeS}</li>)
          )}
        </ul>
      </div>
      <div>
        <input type="text" value={input} onChange={(e) => setInput(e.target.value)} />
        <button type='button' onClick={adicionar}>Adicionar novo</button>
      </div>
    </>
  )
}

export default App
